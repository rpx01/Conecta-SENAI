# Changelog

## [Unreleased]
### Added
- Botão para administradores retornarem à tela de seleção de sistema no menu do usuário.
- Limitação de taxa simples para as rotas `/api/login` e `/api/usuarios`.
### Changed
- Sidebar do Gerenciamento de Usuários atualizada para exibir apenas "Lista de Usuários" e "Meu Perfil".
- Removido carregamento automático do link "Laboratórios e Turmas" nesse módulo.
- Formulário de nova sala simplificado com opções fixas de localização e menos campos.
### Fixed
- Edição de ocupações recorrentes agora ignora o próprio grupo ao verificar disponibilidade.
