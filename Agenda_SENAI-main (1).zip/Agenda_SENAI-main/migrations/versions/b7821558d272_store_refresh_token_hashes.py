"""store refresh token hashes

Revision ID: b7821558d272
Revises: 84ae848229ac
Create Date: 2025-07-10 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa
import hashlib

# revision identifiers, used by Alembic.
revision = 'b7821558d272'
down_revision = '84ae848229ac'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('refresh_tokens', sa.Column('token_hash', sa.String(length=64), nullable=True))

    conn = op.get_bind()
    refresh_tokens = conn.execute(sa.text('SELECT id, token FROM refresh_tokens'))
    for row in refresh_tokens:
        token_hash = hashlib.sha256(row.token.encode()).hexdigest()
        conn.execute(sa.text('UPDATE refresh_tokens SET token_hash=:h WHERE id=:i'), {'h': token_hash, 'i': row.id})

    op.alter_column('refresh_tokens', 'token_hash', nullable=False)
    op.create_unique_constraint(op.f('uq_refresh_tokens_token_hash'), 'refresh_tokens', ['token_hash'])
    op.drop_constraint('refresh_tokens_token_key', 'refresh_tokens', type_='unique')
    op.drop_column('refresh_tokens', 'token')


def downgrade():
    op.add_column('refresh_tokens', sa.Column('token', sa.String(length=512), nullable=True))
    op.drop_constraint(op.f('uq_refresh_tokens_token_hash'), 'refresh_tokens', type_='unique')
    op.drop_column('refresh_tokens', 'token_hash')
    # tokens cannot be restored
    op.create_unique_constraint('refresh_tokens_token_key', 'refresh_tokens', ['token'])

