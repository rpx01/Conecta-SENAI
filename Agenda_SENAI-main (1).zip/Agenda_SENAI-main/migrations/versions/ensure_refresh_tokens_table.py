"""ensure refresh tokens table exists"""

from alembic import op
import sqlalchemy as sa

revision = "c54049d86b85"
down_revision = "b7821558d272"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    if not bind.dialect.has_table(bind, 'refresh_tokens'):
        op.create_table(
            'refresh_tokens',
            sa.Column('id', sa.Integer, primary_key=True),
            sa.Column('user_id', sa.Integer, sa.ForeignKey('usuarios.id'), nullable=False),
            sa.Column('token_hash', sa.String(length=64), nullable=False, unique=True),
            sa.Column('revoked', sa.Boolean(), nullable=False, server_default=sa.text('false')),
            sa.Column('expires_at', sa.DateTime, nullable=False),
            sa.Column('created_at', sa.DateTime, nullable=True),
        )


def downgrade():
    bind = op.get_bind()
    if bind.dialect.has_table(bind, 'refresh_tokens'):
        op.drop_table('refresh_tokens')
