"""Pacote principal da aplicacao."""
