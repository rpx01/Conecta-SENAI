"""Pacote que agrupa os blueprints da aplicacao."""
